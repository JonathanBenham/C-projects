﻿using System;

namespace Ex04.Menus.Interfaces
{
    public class Class1
    {
    }
}
