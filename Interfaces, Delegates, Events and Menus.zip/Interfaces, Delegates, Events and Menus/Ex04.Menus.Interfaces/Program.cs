﻿using System;

namespace Ex04.Menus.Interfaces
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
