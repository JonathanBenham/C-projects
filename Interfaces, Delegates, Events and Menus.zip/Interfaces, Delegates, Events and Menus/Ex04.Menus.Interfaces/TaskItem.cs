﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex04.Menus.Interfaces
{
    public class TaskItem : MenuItem
    {
        private IExecutable m_Executable;

        public IExecutable Executable
        {
            get { return m_Executable; }
            set { m_Executable = value; }
        }

        // $G$ CSS-013 (-3) Bad variable name (should be in the form of: i_CamelCase).
        public TaskItem(string i_name, IExecutable i_executable) : base(i_name)
        {
            Executable = i_executable;
        }

        public void Execute()
        {
            if (Executable != null)
            {
                Executable.Execute();
            }
            else
            {
                Console.WriteLine("Nothing to do.");
            }
        }
    }
}
