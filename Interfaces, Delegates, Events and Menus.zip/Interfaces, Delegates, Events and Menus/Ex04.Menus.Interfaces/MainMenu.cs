﻿using System;
using System.Linq;

namespace Ex04.Menus.Interfaces
{
    public class MainMenu
    {
        public Menu PrincipalMenu { get; set; }

        public void PrintMenu(Menu i_MenuToPrint)
        {
            Console.WriteLine(i_MenuToPrint.ItemList.IndexOf(i_MenuToPrint) + 2 + ". " + i_MenuToPrint.Name);
            Console.WriteLine("==============");

            int index = 1;
            foreach (MenuItem item in i_MenuToPrint.ItemList)
            {
                Console.WriteLine("{0}. {1}", index, item.Name);
                index++;
            }

            Console.WriteLine("0. Exit");
            Console.WriteLine("Please enter your choice (1-{0} or 0 to exit):", i_MenuToPrint.ItemList.Count);
            Console.Write(">> ");
        }

        public void Show()
        {
            Menu menu = PrincipalMenu;
            int menuLength = menu.ItemList.Count;
            PrintMenu(menu);
            string command = Console.ReadLine();
            bool isNum = Int32.TryParse(command, out int commandNum);

            while (!isNum || commandNum > menuLength || commandNum < 0)
            {
                Console.WriteLine("Please write a relevant number");
                command = Console.ReadLine();
                isNum = Int32.TryParse(command, out commandNum);
            }


            while (menu != null)
            {
                if (commandNum == 0 && menu.Parent == null) return;
                else if (commandNum == 0)
                {
                    menu = (Menu)menu.Parent;
                    Console.Clear();
                }
                else if (menu.ItemList.ElementAt(commandNum - 1) is TaskItem task)
                {
                    task.Execute();
                }
                else
                {
                    menu = (Menu)menu.ItemList.ElementAt(commandNum - 1);
                    Console.Clear();
                }
                
                PrintMenu(menu);
                command = Console.ReadLine();
                isNum = Int32.TryParse(command, out commandNum);

                while (!isNum || commandNum > menuLength || commandNum < 0)
                {
                    Console.WriteLine("Please write a relevant number");
                    command = Console.ReadLine();
                    isNum = Int32.TryParse(command, out commandNum);
                }
                Console.Clear();
            }
        }
    }
    
}
