﻿using System;

namespace Ex04.Menus.Delegates
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
