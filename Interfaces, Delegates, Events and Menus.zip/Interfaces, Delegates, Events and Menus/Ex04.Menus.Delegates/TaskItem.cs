﻿using System;

namespace Ex04.Menus.Delegates
{
    public class TaskItem : MenuItem
    {
        public delegate void ExecutorDelegate();
        public event ExecutorDelegate Executed;

        public TaskItem(string i_name, ExecutorDelegate i_executor) : base(i_name)
        {
            Executed = i_executor;
        }


        public void OnExecuted()
        {
            if (Executed != null)
            {
                Executed.Invoke();
            }
            else
            {
                Console.WriteLine("Nothing to do.");
            }
        }
    }
}
