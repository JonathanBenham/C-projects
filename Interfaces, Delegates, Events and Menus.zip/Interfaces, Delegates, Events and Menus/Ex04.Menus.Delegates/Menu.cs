﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex04.Menus.Delegates
{
    public class Menu : MenuItem
    {
        private List<MenuItem> m_ItemList;
        public List<MenuItem> ItemList { 
            get { return m_ItemList; } 
            set { m_ItemList = value; } 
        }

        public Menu(string i_name) : base(i_name)
        {
            m_ItemList = new List<MenuItem>();
        }

        public void Add(MenuItem i_item)
        {
            m_ItemList.Add(i_item);
            i_item.Parent = this;
        }

        public void Remove(MenuItem i_item)
        {
            m_ItemList.Remove(i_item);
        }
    }
}
