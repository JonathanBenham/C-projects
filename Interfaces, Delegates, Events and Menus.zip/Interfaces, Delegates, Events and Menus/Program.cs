﻿using System;

namespace B19_Ex04_Dean_000802794_Jonathan_206822991
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
