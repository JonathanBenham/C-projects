﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ex04.Menus.Interfaces;

namespace Ex04.Test
{
    public class Actions
    {
        public class ShowTime : IExecutable
        {
            public void Execute()
            {
                Console.WriteLine(DateTime.Now.ToShortTimeString());
            }
        }


        public class ShowDate : IExecutable
        {
            public void Execute()
            {
                Console.WriteLine(DateTime.Now.ToShortDateString());
            }
        }

        public class CountsDigits : IExecutable
        {
            public void Execute()
            {
                Console.WriteLine(CountDigits());
            }

            public int CountDigits()
            {
                Console.WriteLine("enter a text");
                String inputText = Console.ReadLine();
                int numOfDigit = 0;
                for (int i = 0; i < inputText.Length; i++)
                {
                    if (char.IsDigit(inputText[i]))
                    {
                        numOfDigit++;
                    }
                }
                return numOfDigit;
            }
        }

        public class DisplayVersion : IExecutable
        {
            public void Execute()
            {
                Console.WriteLine("App Version: 19.2.4.32");
            }
        }
    }
}
