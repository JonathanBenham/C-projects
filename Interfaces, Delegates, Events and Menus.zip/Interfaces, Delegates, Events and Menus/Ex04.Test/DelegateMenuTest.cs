﻿using System;
using Ex04.Menus.Delegates;
using static Ex04.Test.Actions;

namespace Ex04.Test
{
    public class DelegateMenuTest
    {

        public static event Action s_Actions;

        public static void BuildMenu()
        {
            MainMenu delegateMenu = new MainMenu();
            delegateMenu.PrincipalMenu = new Menu("Menu");
            Menu delegatePrincipal = delegateMenu.PrincipalMenu;

            Menu dateTime = new Menu("Show Date/Time");
            Menu versionAndCapitals = new Menu("Version and Digits\"");
            delegatePrincipal.Add(dateTime);
            s_Actions += new Action(ShowTime);
            s_Actions += new Action(ShowDate);
            dateTime.Add(new TaskItem("Show Time", ShowTime));
            dateTime.Add(new TaskItem("Show Date", ShowDate));

            delegatePrincipal.Add(versionAndCapitals);
            s_Actions += new Action(CountCapitals);
            s_Actions += new Action(DisplayVersion);
            versionAndCapitals.Add(new TaskItem("Count Digits", CountsDigits));
            versionAndCapitals.Add(new TaskItem("Display Version", DisplayVersion));

            delegateMenu.Show();
        }

        public static void ShowTime()
        {
            Console.WriteLine(DateTime.Now.ToShortTimeString());
        }

        public static void ShowDate()
        {
            Console.WriteLine(DateTime.Now.ToShortDateString());
        }

        public static void CountCapitals()
        {
            count();
        }

        private static int count()
        {
            Console.WriteLine("enter a text");
            String inputText = Console.ReadLine();
            int numOfDigits = 0;
            for (int i = 0; i < inputText.Length; i++)
            {
                if (char.IsDigit(inputText[i]))
                {
                    numOfDigits++;
                }
            }
            return numOfDigits;
        }

        public static void DisplayVersion()
        {
            Console.WriteLine("App Version: 19.2.4.32");
        }
    }
}
