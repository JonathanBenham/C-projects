﻿using System;
using Ex04.Menus.Interfaces;

namespace Ex04.Test
{
    public class InterfaceMenuTest
    {
        public static void BuildMenu()
        {
            MainMenu interfaceMenu = new MainMenu();
            interfaceMenu.PrincipalMenu = new Menu("Menu");
            Menu interfacePrincipal = interfaceMenu.PrincipalMenu;

            Menu dateTime = new Menu("Show Date/Time");
            Menu versionAndDigits = new Menu("Version and Digits\"");
            interfacePrincipal.Add(dateTime);
            dateTime.Add(new TaskItem("Show Time", new Actions.ShowTime()));
            dateTime.Add(new TaskItem("Show Date", new Actions.ShowDate()));

            interfacePrincipal.Add(versionAndDigits);
            versionAndDigits.Add(new TaskItem("Count Digits", new Actions.CountsDigits()));
            versionAndDigits.Add(new TaskItem("Display Version", new Actions.DisplayVersion()));

            interfaceMenu.Show();
        }
    }
}
