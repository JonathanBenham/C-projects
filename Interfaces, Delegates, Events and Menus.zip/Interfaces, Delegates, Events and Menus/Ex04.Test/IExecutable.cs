﻿namespace Ex04.Test
{
    public interface IExecutable
    {
    }
}