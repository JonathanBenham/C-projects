﻿using System;

namespace Ex04.Test
{
    // $G$ SFN-004 (-5) The sub menu should display a "back" option, and not an "exit" option.
    public class Program
    {
        public static void Main()
        {
            InterfaceMenuTest.BuildMenu();
            DelegateMenuTest.BuildMenu();

        }
    }
}

