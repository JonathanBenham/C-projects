﻿using System;

namespace Ex03.GarageLogic
{
    public class Vehicle
    {
        private String m_ModelName;
        public string ModelName
        {
            get { return m_ModelName; }
        }

        private String m_LicenseNumber;
        public String LicenseNumber
        {
            get { return m_LicenseNumber; }
        }

        private float m_RemainingEnergyPercentage;
        public float RemainingEnergyPercentage 
        {
            get { return m_RemainingEnergyPercentage}
        }

        private Wheels m_Wheels;
        private String m_OwnerName;
        public String OwnerName
        {
            get { return m_OwnerName;  }
        }


        public Vehicle(String i_ModelName, String i_LicenseNumber, float i_RemainingEnergyPercentage, 
            String i_ManufacturerName, float i_CurrentAirPressure, float i_AirPressureRecommended, String i_OwnerName) 
        {
            m_ModelName = i_ModelName;
            m_LicenseNumber = i_LicenseNumber;
            m_RemainingEnergyPercentage = i_RemainingEnergyPercentage;
            m_Wheels = new Wheels(i_ManufacturerName, i_CurrentAirPressure, i_AirPressureRecommended);
            m_OwnerName = i_OwnerName;

        }

        public void InflateWheel(float i_AirToAdd)
        {
            try
            {
                m_Wheels.ChangeCurrentAirOfWheel(i_AirToAdd);
            }
            catch(Exception ArgumentOutOfRangeException)
            {
            }
        } 




    }
}
