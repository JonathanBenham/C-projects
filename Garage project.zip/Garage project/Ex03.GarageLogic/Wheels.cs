﻿using System;
namespace Ex03.GarageLogic
{
    public class Wheels
    {
        private String m_ManufacturerName;
        public String ManufacturerName
        {
            get { return m_ManufacturerName;  }
        }

        private float m_CurrentAirPressure;
        public float CurrentAirPressure
        {
            get { return m_CurrentAirPressure;  }
        }

        private float m_AirPressureRecommended;
        public float AirPressureRecommended
        {
            get { return m_AirPressureRecommended;  }
        }

        public Wheels(string i_ManufacturerName, float i_CurrentAirPressure, float i_AirPressureRecommended)
        {
            m_ManufacturerName = i_ManufacturerName;
            m_CurrentAirPressure = i_CurrentAirPressure;
            m_AirPressureRecommended = i_AirPressureRecommended;
        }

        public void ChangeCurrentAirOfWheel (float i_AirToAdd)
        {
            if (i_AirToAdd + m_CurrentAirPressure > m_AirPressureRecommended)
            {
                Console.WriteLine("The value {0} that you wanted to inflate is bigger than the Recommanded air pressure. " +
                    "We inflate until the recommanded  air pressure ", i_AirToAdd);
                m_CurrentAirPressure = m_AirPressureRecommended;
            }
            else if (i_AirToAdd < 0)
            {
                throw new ArgumentOutOfRangeException("The valu"+ i_AirToAdd + "that you wanted to inflate is less than 0.\n");
            }
            else
            {
                m_CurrentAirPressure = i_AirToAdd;
            }
        
        }
    }
}
