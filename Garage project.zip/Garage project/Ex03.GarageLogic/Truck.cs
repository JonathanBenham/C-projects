﻿using System;
namespace Ex03.GarageLogic
{
    public class Truck : Vehicle
    {
        public Truck()
        {
        }
    }
}
