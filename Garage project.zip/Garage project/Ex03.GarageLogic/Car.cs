﻿using System;
namespace Ex03.GarageLogic
{
    public class Car : Vehicle
    {
        protected enum NumOfDoors {2, 3, 4, 5};
        public int m_NumOfDoors;


        // creating constructor and calling base class constructor as well
        public Car(String i_ModelName, String i_LicenseNumber, float i_RemainingEnergyPercentage,
            String i_ManufacturerName, float i_CurrentAirPressure, float i_AirPressureRecommended, int i_NumOfDoorsRequested) : 
            base(i_ModelName, i_LicenseNumber, i_RemainingEnergyPercentage,
             i_ManufacturerName, i_CurrentAirPressure, i_AirPressureRecommended)
        {
            try
            {
                m_NumOfDoors = i_NumOfDoorsRequested;

            }
            catch (Exception )
            {

            }
        }

        public void DisplayInfo()
        {

        }
    }
}
